package com.yhack.eetutor.activities

object MainRepository