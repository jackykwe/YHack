.read init.sql
.import --csv test-data/person.csv Person
.import --csv test-data/student.csv Student
.import --csv test-data/tutor.csv Tutor
.import --csv test-data/subject.csv Subject
.import --csv test-data/ability.csv Ability
.import --csv test-data/teaches.csv Teaches